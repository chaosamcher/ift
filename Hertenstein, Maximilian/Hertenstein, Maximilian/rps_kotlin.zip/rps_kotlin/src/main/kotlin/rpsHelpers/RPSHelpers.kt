package rpsHelpers

fun greetPlayerAskChoiceHelper(playerName: String): String =
    "Hey " + playerName + "! Please choose rock, paper or scissors!"

fun showRoundNumber(currentRound: Int, roundsToPlay: Int): String =
    currentRound.toString() + ". of " + roundsToPlay.toString() + " Rounds"

fun greetPlayerAskNameHelper(number: Int): String = "Hello Player " + number.toString() + "! What's your name?"


// ------------- Bedingungen


fun showPlayerPoints(name: String, points: Int): String =
    name + " has " + points.toString() + " " + if (points == 1) "point" else "points"


fun showPlayersPoints(
    player1Name: String,
    player2Name: String,
    player1Points: Int,
    player2Points: Int
): String = showPlayerPoints(player1Name, player1Points) + "\n" + showPlayerPoints(player2Name, player2Points)


fun computeRoundWinner(p1: String, p2: String): String =
    when {
        p1 == p2 -> "Nobody"
        p1 == "rock" && p2 == "scissors" || p1 == "paper" && p2 == "rock" || p1 == "scissors" && p2 == "paper" -> "1"
        else -> "2"
    }


fun showWinnerWithNameHelper(
    winner: String,
    player1Name: String,
    player2Name: String,
    fullGame: Boolean
): String {
    val winnerName = when {
        winner == "1" -> player1Name
        winner == "2" -> player2Name
        else -> "Nobody"
    }
    return winnerName + " wins this " + (if (fullGame) "game" else "round") + "!"
}

fun showRoundWinnerWithName(roundWinner: String, player1Name: String, player2Name: String): String =
    showWinnerWithNameHelper(roundWinner, player1Name, player2Name, false)

fun showGameWinnerWithName(
    player1Name: String,
    player2Name: String,
    player1Points: Int,
    player2Points: Int
): String {
    val gameWinner = when {
        player1Points > player2Points -> "1"
        player2Points > player1Points -> "2"
        else -> "Nobody"
    }
    return showWinnerWithNameHelper(
        gameWinner,
        player1Name,
        player2Name,
        true
    )
}


fun computeNewPoints(roundWinner: String, playerNumber: Int, currentPoints: Int) =
    if (playerNumber.toString() == roundWinner) currentPoints + 1 else currentPoints


