import rpsHelpers.*




fun main(){
}